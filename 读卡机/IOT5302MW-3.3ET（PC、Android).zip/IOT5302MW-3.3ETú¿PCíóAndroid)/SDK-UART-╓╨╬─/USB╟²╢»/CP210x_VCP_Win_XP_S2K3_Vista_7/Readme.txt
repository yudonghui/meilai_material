This is the installer for the driver needed for the CXJ reader:

    CP210x USB to UART Bridge VCP Drivers

Note that on some computers, such as a Windows 7 machine, this driver may be automatically installed when the reader is first connected.
